FastLane documentation
================
This folder contains hermetic scripts to re-build the app using a distribution
profile and then deploy to TestFlight.

This is done using the [FastLane](https://fastlane.tools) tool suite.

Deployment can be done manually by Googlers by following
go/flutter-gallery-publish (internal doc).

Deployment is automatically done by Cirrus on tagged branch commits.