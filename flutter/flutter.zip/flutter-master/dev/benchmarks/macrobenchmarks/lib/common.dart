const String kCullOpacityRouteName = '/cull_opacity';
