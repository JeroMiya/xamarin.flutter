This is a fake package for use by automated testing.
For example, the `flutter_tools` package uses this to test `flutter test`.
